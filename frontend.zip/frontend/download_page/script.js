function downloadData(platform) {
  const baseUrl = "http://127.0.0.1:5000"; // Backend server URL
  const endpoints = {
    youtube: `${baseUrl}/export/exportyoutube`,
    instagram: `${baseUrl}/export/exportinstagram`,
    linkedin: `${baseUrl}/export/exportlinkedin`,
    facebook: `${baseUrl}/export/exportfacebook`,
  };

  const url = endpoints[platform];
  if (url) {
    // Redirect the user to the endpoint to download the CSV
    window.location.href = url;
  } else {
    alert("Invalid platform selected!");
  }
}
