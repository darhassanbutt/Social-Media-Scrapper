// Instagram Form Handler for User Data
document
.getElementById("apply-filter-btn")
.addEventListener("click", function () {
  const jsonView = document.getElementById("json-view");
  if (currentData) {
    let filteredData;
    if (currentDataType === "info") {
      filteredData = filterInstagramUserData(currentData);
    } else if (
      currentDataType === "followers" ||
      currentDataType === "following"
    ) {
      filteredData = filterInstagramList(currentData);
    } else if(currentDataType === "post_info" || currentDataType === "post_comments" || currentDataType === "post_likes"|| currentDataType==="post_posts"||currentDataType==="post_stories"){
           filteredData = filterPostDetails(currentData);
      }
    if (filteredData) {
      jsonView.textContent = JSON.stringify(filteredData, null, 2);
      jsonView.style.whiteSpace = "pre-wrap";
    } else {
      jsonView.textContent = "No data available for filtering";
    }
  } else {
    alert("No data available to filter!");
  }
});
document
  .getElementById("instagram-form")
  .addEventListener("submit", function (event) {
    event.preventDefault();

    const username = document.getElementById("instagram-username").value.trim();
    if (!username) {
      alert("Please enter a username.");
      return;
    }
  });

// Instagram Form Button Handlers
document.getElementById("get-info-btn").addEventListener("click", function () {
  const username = document.getElementById("instagram-username").value.trim();
  if (!username) {
    alert("Please enter a username.");
    return;
  }
  scrapeInstagramData(username, "info");
});

document
  .getElementById("get-followers-btn")
  .addEventListener("click", function () {
    const username = document.getElementById("instagram-username").value.trim();
    if (!username) {
      alert("Please enter a username.");
      return;
    }
    scrapeInstagramData(username, "followers");
  });

document
  .getElementById("get-followings-btn")
  .addEventListener("click", function () {
    const username = document.getElementById("instagram-username").value.trim();
    if (!username) {
      alert("Please enter a username.");
      return;
    }
    scrapeInstagramData(username, "following");
  });

document.getElementById("get-posts-btn").addEventListener("click", function () {
  const username = document.getElementById("instagram-username").value.trim();
  if (!username) {
    alert("Please enter a username.");
    return;
  }
  scrapeInstagramData(username, "posts");
});

document
  .getElementById("get-stories-btn")
  .addEventListener("click", function () {
    const username = document.getElementById("instagram-username").value.trim();
    if (!username) {
      alert("Please enter a username.");
      return;
    }
    scrapeInstagramData(username, "stories");
  });

// Instagram Post Details Form Button Handlers
document
  .getElementById("fetch-post-details-btn-info")
  .addEventListener("click", function () {
    const postUrl = document.getElementById("post-url").value.trim();
    if (!postUrl) {
      alert("Please enter a valid Instagram post URL.");
      return;
    }
    fetchPostDetails(postUrl, "info");
  });

document
  .getElementById("fetch-post-details-btn-comments")
  .addEventListener("click", function () {
    const postUrl = document.getElementById("post-url").value.trim();
    if (!postUrl) {
      alert("Please enter a valid Instagram post URL.");
      return;
    }
    fetchPostDetails(postUrl, "comments");
  });

document
  .getElementById("fetch-post-details-btn-likes")
  .addEventListener("click", function () {
    const postUrl = document.getElementById("post-url").value.trim();
    if (!postUrl) {
      alert("Please enter a valid Instagram post URL.");
      return;
    }
    fetchPostDetails(postUrl, "likes");
  });

  let currentData = null;
  let currentDataType = null;
  async function scrapeInstagramData(username, type) {
    const loader = document.getElementById("loader");
    const jsonView = document.getElementById("json-view");
    try {
        jsonView.innerHTML = "";
        loader.style.display = "block";
        const response = await fetch(
            `http://127.0.0.1:5000/scraper/instagram/user/${type}?username=${encodeURIComponent(
                username
            )}`,
            {
                method: "GET",
                headers: {
                    "Content-Type": "application/json",
                },
            }
        );
        if (response.ok) {
            const data = await response.json();
            console.log(data);
            currentData = data;
            if (type === "posts") {
                  currentDataType = "post_posts";
            } else if (type === "stories") {
                  currentDataType = "post_stories";
            } else {
                   currentDataType = type
              }
            jsonView.textContent = JSON.stringify(data, null, 2);
            jsonView.style.whiteSpace = "pre-wrap";
        } else {
            throw new Error("Failed to fetch user data from the server");
        }
    } catch (error) {
        console.error("Error:", error);
        alert("An error occurred while fetching data. Please try again.");
    } finally {
        loader.style.display = "none";
    }
}
  async function fetchPostDetails(postUrl, type) {
    const loader = document.getElementById("post-loader");
    const jsonView = document.getElementById("json-view");
    try {
      jsonView.innerHTML = "";
      loader.style.display = "block";
      // API request based on the type of action (Post data)
      const response = await fetch(
        `http://127.0.0.1:5000/scraper/instagram/post/${type}?url=${encodeURIComponent(
          postUrl
        )}`,
        {
          method: "GET",
          headers: {
            "Content-Type": "application/json",
          },
        }
      );
      if (response.ok) {
        const data = await response.json();
        console.log(data);
        currentData= data;
        currentDataType= "post_"+type;
          jsonView.textContent=JSON.stringify(data,null,2);
          jsonView.style.whiteSpace ="pre-wrap";
      } else {
        throw new Error("Failed to fetch post data from the server");
      }
    } catch (error) {
      console.error("Error:", error);
      alert("An error occurred while fetching post details. Please try again.");
    } finally {
      loader.style.display = "none";
    }
  }

function displayInstagramData(rawData, type) {
  const jsonView = document.getElementById("json-view");
   let filteredData;

  if (type === "info") {
   filteredData = filterInstagramUserData(rawData);
  } else if (type === "followers" || type === "following") {
    filteredData = filterInstagramList(rawData);
 } else{
   filteredData = rawData;
 }
      if (filteredData) {
         jsonView.textContent = JSON.stringify(filteredData,null,2);
         jsonView.style.whiteSpace = "pre-wrap";
      } else {
            jsonView.textContent = "Data not found";
      }
}

function displayPostDetails(rawData) {
  const jsonView = document.getElementById("json-view");
  const filteredData = filterPostDetails(rawData);
   if(filteredData){
       jsonView.textContent = JSON.stringify(filteredData,null,2);
        jsonView.style.whiteSpace = "pre-wrap";
   } else{
        jsonView.textContent = "Data not found"
   }

}
function filterPostDetails(rawData) {
  if (!rawData || !rawData.data) {
    return null;
  }
  const data = rawData.data;
    if (currentDataType === "post_likes" && data.items) {
        return data.items.map(item => ({
            username: item.username || "N/A",
            full_name: item.full_name || "N/A",
            profile_pic_url: item.profile_pic_url || "",
        }));
    } else if(currentDataType === "post_posts" && data.items){
         return data.items.map(item =>({
              caption: item.caption?.text || "N/A",
                like_count: item.metrics?.like_count || 0,
              comment_count: item.metrics?.comment_count || 0,
                created_at: item.taken_at || "N/A"
            }));
        }  else if (currentDataType === "post_stories" && data.items) {
      
       return  data.items.map(item =>({
             
                id: item.id || "N/A",
                 created_at: item.created_at || "N/A",
                  profile_pic_url: item.user?.profile_pic_url || "N/A",
                  username: item.user?.username || "N/A",
               }))

  } else if (data.items) {
      return data.items.map((item) => ({
        username: item.user?.username || "N/A",
        full_name: item.user?.full_name || "N/A",
        profile_pic_url: item.user?.profile_pic_url || "",
        text: item.text || "N/A",
        comment_like_count:item.comment_like_count || 0,
        like_count:item.like_count ||0
      }));
  } else {
    return {
        caption: data.caption?.text || "N/A",
        like_count: data.metrics?.like_count || 0,
        comment_count: data.metrics?.comment_count || 0,
        created_at: data.taken_at || "N/A",
    };
    }
}

// Export JSON functionality
document
  .getElementById("export-json-btn")
  .addEventListener("click", function () {
    if (!currentData) {
      alert("No data available to export!");
      return;
    }

    const blob = new Blob([JSON.stringify(currentData, null, 2)], {
      type: "application/json",
    });
    const url = URL.createObjectURL(blob);

    const a = document.createElement("a");
    a.href = url;
    a.download = "instagram_data.json";
    a.click();

    URL.revokeObjectURL(url);
  });
  function filterInstagramUserData(rawData) {
    if (!rawData || !rawData.data) {
      return null; // Handle cases with missing or invalid data
    }
    const data = rawData.data;
  
    return {
      username: data.username || "N/A",
      full_name: data.full_name || "N/A",
      follower_count: data.follower_count || 0,
      following_count: data.following_count || 0,
      profile_pic_url: data.profile_pic_url || "",
      biography: data.biography || "",
      is_private: data.is_private || false,
      is_verified: data.is_verified || false
    };
  }
  function filterInstagramList(rawData) {
    if (!rawData || !rawData.data || !rawData.data.items) {
      return null; // Handle cases where items are missing
    }
     
    const items = rawData.data.items;
  
    return items.map(item => ({
      username: item.username || "N/A",
      full_name: item.full_name || "N/A",
      profile_pic_url: item.profile_pic_url || "",
      is_private: item.is_private || false,
       is_verified: item.is_verified||false
    }));
  }