// Facebook Form Handler for Post Data
document
  .getElementById("facebook-form")
  .addEventListener("submit", function (event) {
    event.preventDefault();

    const postId = document.getElementById("facebook-username").value.trim();
    if (!postId) {
      alert("Please enter a Facebook post ID.");
      return;
    }

    scrapeFacebookData(postId);
  });

// Facebook Scraping Function
async function scrapeFacebookData(postId) {
  const loader = document.getElementById("facebook-loader");
  const jsonView = document.getElementById("json-view");

  try {
    jsonView.innerHTML = ""; // Clear previous results
    loader.style.display = "block"; // Show loader

    const response = await fetch(
      `http://127.0.0.1:5000/scraper/facebook?post_id=${encodeURIComponent(
        postId
      )}`,
      {
        method: "GET",
        headers: {
          "Content-Type": "application/json",
        },
      }
    );

    if (response.ok) {
      const data = await response.json();
      console.log(data);
      displayFacebookData(data);
    } else {
      throw new Error("Failed to fetch Facebook post data from the server");
    }
  } catch (error) {
    console.error("Error:", error);
    alert("An error occurred while fetching data. Please try again.");
  } finally {
    loader.style.display = "none"; // Hide loader
  }
}

// Display Facebook Data in JSON Format
function displayFacebookData(data) {
  const jsonView = document.getElementById("json-view");

  // Format and display the JSON data in a readable way
  jsonView.textContent = JSON.stringify(data, null, 2);
  jsonView.style.whiteSpace = "pre-wrap";

  // Show export JSON button
  document.getElementById("export-json-btn").style.display = "inline-block";
}

// Export JSON functionality for Facebook data
document
  .getElementById("export-json-btn")
  .addEventListener("click", function () {
    const jsonView = document.getElementById("json-view");

    if (!jsonView.textContent.trim()) {
      alert("No data available to export!");
      return;
    }

    const blob = new Blob([jsonView.textContent], { type: "application/json" });
    const url = URL.createObjectURL(blob);

    const a = document.createElement("a");
    a.href = url;
    a.download = "facebook_post_data.json";
    a.click();

    URL.revokeObjectURL(url);
  });
