// Form Handlers for YouTube Channel and Video Data
document
  .getElementById("youtube-form")
  .addEventListener("submit", function (event) {
    event.preventDefault();
    alert("Use the buttons to fetch specific data.");
  });

document
  .getElementById("youtube-video-details-form")
  .addEventListener("submit", function (event) {
    event.preventDefault();
    alert("Use the buttons to fetch specific video data.");
  });

// Button Handlers for Channel Data
document
  .getElementById("get-channel-details-btn")
  .addEventListener("click", function () {
    const channelId = document.getElementById("youtube-channel").value.trim();
    if (!channelId) {
      alert("Please enter a valid Channel ID.");
      return;
    }
    scrapeYouTubeData(channelId, "channel/info");
  });

document
  .getElementById("get-channel-videos-btn")
  .addEventListener("click", function () {
    const channelId = document.getElementById("youtube-channel").value.trim();
    if (!channelId) {
      alert("Please enter a valid Channel ID.");
      return;
    }
    scrapeYouTubeData(channelId, "channel/videos");
  });

document
  .getElementById("get-channel-playlists-btn")
  .addEventListener("click", function () {
    const channelId = document.getElementById("youtube-channel").value.trim();
    if (!channelId) {
      alert("Please enter a valid Channel ID.");
      return;
    }
    scrapeYouTubeData(channelId, "channel/playlists");
  });

document
  .getElementById("get-channel-shorts-btn")
  .addEventListener("click", function () {
    const channelId = document.getElementById("youtube-channel").value.trim();
    if (!channelId) {
      alert("Please enter a valid Channel ID.");
      return;
    }
    scrapeYouTubeData(channelId, "channel/shorts");
  });

// Button Handlers for Video Data
document
  .getElementById("get-video-info-btn")
  .addEventListener("click", function () {
    const videoUrl = document.getElementById("youtube-video-url").value.trim();
    if (!videoUrl) {
      alert("Please enter a valid Video URL.");
      return;
    }
    scrapeYouTubeData(videoUrl, "video/info");
  });

document
  .getElementById("get-video-comments-btn")
  .addEventListener("click", function () {
    const videoUrl = document.getElementById("youtube-video-url").value.trim();
    if (!videoUrl) {
      alert("Please enter a valid Video URL.");
      return;
    }
    scrapeYouTubeData(videoUrl, "video/subtitle");
  });

let currentYouTubeData = null;

// Function to Scrape YouTube Data
async function scrapeYouTubeData(id, type) {
  const loader = document.getElementById("youtube-loader");
  const jsonView = document.getElementById("json-view");

  try {
    jsonView.innerHTML = "";
    loader.style.display = "block";

    const response = await fetch(
      `http://127.0.0.1:5000/scraper/youtube/${type}?id=${encodeURIComponent(
        id
      )}`,
      {
        method: "GET",
        headers: {
          "Content-Type": "application/json",
        },
      }
    );

    if (response.ok) {
      const data = await response.json();
      console.log(data);
      currentYouTubeData = data;
      displayYouTubeData(data);
    } else {
      throw new Error("Failed to fetch data from the server");
    }
  } catch (error) {
    console.error("Error:", error);
    alert("An error occurred while fetching data. Please try again.");
  } finally {
    loader.style.display = "none";
  }
}

// Function to Display YouTube Data
function displayYouTubeData(data) {
  const jsonView = document.getElementById("json-view");

  // Format and display the JSON data in a readable way
  jsonView.textContent = JSON.stringify(data, null, 2);
  jsonView.style.whiteSpace = "pre-wrap";
}

// Export JSON Functionality
document
  .getElementById("export-json-btn")
  .addEventListener("click", function () {
    if (!currentYouTubeData) {
      alert("No data available to export!");
      return;
    }

    const blob = new Blob([JSON.stringify(currentYouTubeData, null, 2)], {
      type: "application/json",
    });
    const url = URL.createObjectURL(blob);

    const a = document.createElement("a");
    a.href = url;
    a.download = "youtube_data.json";
    a.click();

    URL.revokeObjectURL(url);
  });
  
