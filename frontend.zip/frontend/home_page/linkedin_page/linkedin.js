// LinkedIn Form Handler for User Data
document
  .getElementById("linkedin-form")
  .addEventListener("submit", function (event) {
    event.preventDefault();

    const url = document.getElementById("linkedin-username").value.trim();
    if (!url) {
      alert("Please enter a LinkedIn URL.");
      return;
    }

    scrapeLinkedinData(url);
  });

// LinkedIn Scraping Function
async function scrapeLinkedinData(url) {
  const loader = document.getElementById("loader");
  const jsonView = document.getElementById("json-view");

  try {
    jsonView.innerHTML = "";
    loader.style.display = "block";

    const response = await fetch(
      `http://127.0.0.1:5000/scraper/linkedin?url=${encodeURIComponent(url)}`,
      {
        method: "GET",
        headers: {
          "Content-Type": "application/json",
        },
      }
    );

    if (response.ok) {
      const data = await response.json();
      console.log(data);
      displayLinkedinData(data);
    } else {
      throw new Error("Failed to fetch LinkedIn data from the server");
    }
  } catch (error) {
    console.error("Error:", error);
    alert("An error occurred while fetching data. Please try again.");
  } finally {
    loader.style.display = "none";
  }
}

// Display LinkedIn Data in JSON Format
function displayLinkedinData(data) {
  const jsonView = document.getElementById("json-view");

  // Format and display the JSON data in a readable way
  jsonView.textContent = JSON.stringify(data, null, 2);
  jsonView.style.whiteSpace = "pre-wrap";

  // Show export JSON button
  document.getElementById("export-json-btn").style.display = "inline-block";
}

// Export JSON functionality for LinkedIn data
document
  .getElementById("export-json-btn")
  .addEventListener("click", function () {
    const jsonView = document.getElementById("json-view");

    if (!jsonView.textContent.trim()) {
      alert("No data available to export!");
      return;
    }

    const blob = new Blob([jsonView.textContent], { type: "application/json" });
    const url = URL.createObjectURL(blob);

    const a = document.createElement("a");
    a.href = url;
    a.download = "linkedin_data.json";
    a.click();

    URL.revokeObjectURL(url);
  });
